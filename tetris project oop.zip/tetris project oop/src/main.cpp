#include <raylib.h>
#include "game.h"
#include "colors.h"
#include <iostream>
#include <fstream>
using namespace std;

double lastUpdateTime = 0;

class StoreGameInfo {
public:
    static int count;
    int highscore;
    StoreGameInfo(){
        highscore = 0;
    }
};

bool EventTriggered(double interval)
{
    double currentTime = GetTime();
    if (currentTime - lastUpdateTime >= interval)
    {
        lastUpdateTime = currentTime;
        return true;
    }
    return false;
}
int StoreGameInfo :: count = 0;
int main()
{
    StoreGameInfo k;
    InitWindow(500, 620, "Tetris");
    SetTargetFPS(60);

    Font font = LoadFontEx("Font/monogram.ttf", 64, 0, 0);
    Game game = Game();
    bool onTitleScreen = true;

    Rectangle playButton = { 215, 275, 100, 50 };
    Rectangle creditsButton = { 185, 375, 130, 50 };

    while (!WindowShouldClose())
    {
        UpdateMusicStream(game.music);
        Vector2 mousePoint = GetMousePosition();

        BeginDrawing();
        ClearBackground(darkBlue);

        if (onTitleScreen)
        {
            DrawRectangleRounded(playButton, 0.3, 6, lightBlue);
            DrawTextEx(font, "Play", { playButton.x + 10, playButton.y + 5 }, 38, 2, WHITE);

            DrawRectangleRounded(creditsButton, 0.3, 6, lightBlue);
            DrawTextEx(font, "Credits", { creditsButton.x + 5, creditsButton.y + 5 }, 38, 2, WHITE);

            if (IsMouseButtonPressed(MOUSE_LEFT_BUTTON))
            {
                if (CheckCollisionPointRec(mousePoint, playButton))
                {
                    onTitleScreen = false;
                }
                else if (CheckCollisionPointRec(mousePoint, creditsButton))
                {
                    cout << "Credits clicked!" << endl;

                    ofstream file("Credits.txt", ios::out);
                    file << "The Project has been Created by\n"
                         << "1. Shaikh Waqar Mansoor\n"
                         << "2. Waleed Riasat\n"
                         << "3. Omer Rehan\n"
                         << "Our Team Proudly presents to you: Tetris\n";
                    file.close();
                }
            }
        }
        else
        {
            game.HandleInput();

            if (EventTriggered(0.2))
            {
                game.MoveBlockDown();
            }

            DrawTextEx(font, "Score", { 365, 15 }, 38, 2, WHITE);
            DrawTextEx(font, "Next", { 370, 175 }, 38, 2, WHITE);

            if (game.gameOver)
            {
                DrawTextEx(font, "GAME OVER", { 320, 450 }, 38, 2, WHITE);

    
                static bool scoreSaved = false;
                if (!scoreSaved)
                {
                    if(game.score>k.highscore){
                        k.highscore = game.score;
                    }
                    ofstream file1("Score.txt", ios::out);
                    file1 << "Final Score: " << game.score <<", Session High Score :"<<k.highscore<<"User No : "<<k.count<<endl;
                    file1.close();
                    scoreSaved = true;
                }
            }

            DrawRectangleRounded({ 320, 55, 170, 60 }, 0.3, 6, lightBlue);
            char scoreText[10];
            sprintf(scoreText, "%d", game.score);
            Vector2 textSize = MeasureTextEx(font, scoreText, 38, 2);
            DrawTextEx(font, scoreText, { 320 + (170 - textSize.x) / 2, 65 }, 38, 2, WHITE);

            DrawRectangleRounded({ 320, 215, 170, 180 }, 0.3, 6, lightBlue);
            game.Draw();
        }

        EndDrawing();
    }

    CloseWindow();
}
